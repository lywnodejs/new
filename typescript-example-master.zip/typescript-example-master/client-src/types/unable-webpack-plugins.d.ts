declare module 'html-webpack-plugin'

declare module 'qiniu-webpack-plugin'