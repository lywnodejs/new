import path from 'path'

export const app = 'typescript-example'
export const port = 8888
export const distPath = path.resolve(__dirname, '../../client-dist')