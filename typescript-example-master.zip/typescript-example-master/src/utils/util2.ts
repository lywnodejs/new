export default () => console.log('util2')
